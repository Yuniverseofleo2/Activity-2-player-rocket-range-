using UnityEngine;

public class RocketPowerUp : MonoBehaviour
{
    [SerializeField] private float fallSpeed = 3f;
    [SerializeField] private float destroyYPosition = -6f;
    [SerializeField] private float pickupDistance = 1f;

    private Transform playerTransform;
    private bool collected;

    private void Start()
    {
        if (GameManager.Instance != null)
        {
            playerTransform = GameManager.Instance.GetPlayer();
        }
    }

    private void Update()
    {
        if (collected)
        {
            return;
        }

        transform.position += Vector3.down * fallSpeed * Time.deltaTime;

        if (playerTransform != null)
        {
            float distance = Vector2.Distance(
                playerTransform.position,
                transform.position
            );

            if (distance <= pickupDistance)
            {
                collected = true;

                if (GameManager.Instance != null)
                {
                    GameManager.Instance.AddRocket();
                }

                gameObject.SetActive(false);
                return;
            }
        }

        if (transform.position.y < destroyYPosition)
        {
            collected = true;
            gameObject.SetActive(false);
        }
    }
}