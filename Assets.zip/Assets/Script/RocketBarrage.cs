using UnityEngine;

public class RocketBarrage : MonoBehaviour
{
    [SerializeField] private GameObject rocketPrefab;
    [SerializeField] private float fireInterval = 3f;
    [SerializeField] private int rocketCount = 4;
    [SerializeField] private int maxRocketCount = 8;

    private void Start()
    {
        InvokeRepeating(nameof(FireBarrage), fireInterval, fireInterval);
    }

    private void FireBarrage()
    {
        if (rocketPrefab == null) return;

        for (int i = 0; i < rocketCount; i++)
        {
            float angle = 45f + (360f / rocketCount) * i;
            float radians = angle * Mathf.Deg2Rad;

            Vector2 direction = new Vector2(
                Mathf.Cos(radians),
                Mathf.Sin(radians)
            );

            GameObject rocket = Instantiate(
                rocketPrefab,
                transform.position,
                Quaternion.identity
            );

            if (rocket.TryGetComponent<Rocket>(out var rocketScript))
            {
                rocketScript.SetDirection(direction);
            }
        }
    }

    public void AddRocket()
    {
        if (rocketCount < maxRocketCount)
        {
            rocketCount++;
        }
    }

    private void OnDestroy()
    {
        CancelInvoke();
    }
}