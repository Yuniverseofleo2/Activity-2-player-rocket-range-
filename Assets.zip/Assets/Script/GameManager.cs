using UnityEngine;
using TMPro;

public class GameManager : MonoBehaviour
{
    public static GameManager Instance;

    [Header("Player")]
    [SerializeField] private PlayerMovement player;

    [Header("Power Up Spawner")]
    [SerializeField] private GameObject[] powerUpPrefabs;
    [SerializeField] private float spawnInterval = 4f;
    [SerializeField] private float spawnDistance = 3f;

    [Header("Rocket Settings")]
    [SerializeField] private int rocketCount = 4;
    [SerializeField] private int maxRocketCount = 8;

    [Header("UI")]
    [SerializeField] private TMP_Text rocketCountText;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        UpdateRocketCountUI();
        InvokeRepeating(nameof(SpawnRandomPowerUp), 1f, spawnInterval);
    }

    private void SpawnRandomPowerUp()
    {
        if (player == null)
        {
            return;
        }

        if (powerUpPrefabs == null || powerUpPrefabs.Length == 0)
        {
            return;
        }

        int randomIndex = Random.Range(0, powerUpPrefabs.Length);

        GameObject selectedPrefab = powerUpPrefabs[randomIndex];

        Vector2 randomOffset = Random.insideUnitCircle * spawnDistance;

        Vector3 spawnPosition = player.transform.position + new Vector3(
            randomOffset.x,
            randomOffset.y,
            0f
        );

        Instantiate(selectedPrefab, spawnPosition, Quaternion.identity);
    }

    public void AddRocket()
    {
        if (rocketCount < maxRocketCount)
        {
            rocketCount++;
            UpdateRocketCountUI();
        }
    }

    public int GetRocketCount()
    {
        return rocketCount;
    }

    public int GetMaxRocketCount()
    {
        return maxRocketCount;
    }

    public Transform GetPlayer()
    {
        if (player != null)
        {
            return player.transform;
        }

        return null;
    }

    private void UpdateRocketCountUI()
    {
        if (rocketCountText != null)
        {
            rocketCountText.text = "Rockets: " + rocketCount;
        }
    }

    private void OnDestroy()
    {
        CancelInvoke();
    }
}