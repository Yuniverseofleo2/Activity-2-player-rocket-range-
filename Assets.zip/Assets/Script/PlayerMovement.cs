using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerMovement : MonoBehaviour
{
    [SerializeField] private float moveSpeed = 5f;

    [Header("Rocket Settings")]
    [SerializeField] private GameObject rocketPrefab;
    [SerializeField] private float fireInterval = 3f;
    [SerializeField] private Vector3 rocketSpawnOffset = new Vector3(0f, -0.5f, 0f);

    private void Start()
    {
        InvokeRepeating(nameof(FireBarrage), fireInterval, fireInterval);
    }

    private void Update()
    {
        MovePlayer();
    }

    private void MovePlayer()
    {
        Vector3 movement = Vector3.zero;

        if (Keyboard.current.aKey.isPressed || Keyboard.current.leftArrowKey.isPressed)
        {
            movement = Vector3.left;
        }
        else if (Keyboard.current.dKey.isPressed || Keyboard.current.rightArrowKey.isPressed)
        {
            movement = Vector3.right;
        }
        else if (Keyboard.current.wKey.isPressed || Keyboard.current.upArrowKey.isPressed)
        {
            movement = Vector3.up;
        }
        else if (Keyboard.current.sKey.isPressed || Keyboard.current.downArrowKey.isPressed)
        {
            movement = Vector3.down;
        }

        transform.position += movement * moveSpeed * Time.deltaTime;
    }

    private void FireBarrage()
    {
        if (rocketPrefab == null || GameManager.Instance == null)
        {
            return;
        }

        int rocketCount = GameManager.Instance.GetRocketCount();

        for (int i = 0; i < rocketCount; i++)
        {
            float angle = 45f + (360f / rocketCount) * i;
            float radians = angle * Mathf.Deg2Rad;

            Vector2 direction = new Vector2(
                Mathf.Cos(radians),
                Mathf.Sin(radians)
            );

            Vector3 spawnPosition = transform.position + rocketSpawnOffset;

            GameObject rocket = Instantiate(
                rocketPrefab,
                spawnPosition,
                Quaternion.identity
            );

            if (rocket.TryGetComponent<Rocket>(out var rocketScript))
            {
                rocketScript.SetDirection(direction);
            }
        }
    }

    private void OnDestroy()
    {
        CancelInvoke();
    }
}